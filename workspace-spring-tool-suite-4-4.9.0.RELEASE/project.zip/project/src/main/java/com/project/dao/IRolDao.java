package com.project.dao;

import org.springframework.data.repository.CrudRepository;

import com.project.entities.Rol;

public interface IRolDao extends CrudRepository<Rol, Integer> {

}
