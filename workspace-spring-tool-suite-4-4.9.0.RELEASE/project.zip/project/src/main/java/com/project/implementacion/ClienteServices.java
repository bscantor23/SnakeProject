package com.project.implementacion;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.project.dao.IUsuarioDao;
import com.project.entities.Usuario;
import com.project.services.IUsuarioServices;

@Service
public class ClienteServices implements IUsuarioServices{
	
	@Autowired
	private IUsuarioDao clienteDao;
	
	@Transactional(readOnly = true)
	public List<Usuario> findAll() {
		return (List<Usuario>) clienteDao.findAll();
	}
	
	@Transactional(readOnly = true)
	public Optional<Usuario> findById(Integer id) {
		return clienteDao.findById(id);
	}
	
	@Transactional(readOnly = false)
	public void create(Usuario usuario){
		clienteDao.save(usuario);
	}
	
	@Transactional(readOnly = false)
	public void update(Usuario usuario){
		clienteDao.save(usuario);
	}
	
	@Transactional(readOnly = false)
	public void delete(Integer id){
		clienteDao.deleteById(id);
	}
}
