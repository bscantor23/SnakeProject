package com.project.implementacion;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.project.dao.IDependenciaDao;
import com.project.entities.Dependencia;
import com.project.services.IDependenciaServices;

@Service
public class DependenciaServices implements IDependenciaServices{
	
	@Autowired
	private IDependenciaDao dependenciaDao;
	
	@Transactional(readOnly = true)
	public List<Dependencia> findAll() {
		return (List<Dependencia>) dependenciaDao.findAll();
	}
	
	@Transactional(readOnly = true)
	public Optional<Dependencia> findById(Integer id) {
		return dependenciaDao.findById(id);
	}
	
	@Transactional(readOnly = false)
	public void create(Dependencia dependencia){
		dependenciaDao.save(dependencia);
	}
	
	@Transactional(readOnly = false)
	public void update(Dependencia dependencia){
		dependenciaDao.save(dependencia);
	}
	
	@Transactional(readOnly = false)
	public void delete(Integer id){
		dependenciaDao.deleteById(id);
	}
}
