package com.project.services;

import java.util.List;
import java.util.Optional;

import com.project.entities.Rol;

public interface IRolServices {
	public List<Rol> findAll();
	public Optional<Rol> findById(Integer id);
	public void create(Rol rol);
	public void update(Rol rol);
	public void delete(Integer id);
}
