package com.project.services;

import java.util.List;
import java.util.Optional;

import com.project.entities.Dependencia;

public interface IDependenciaServices {
	public List<Dependencia> findAll();
	public Optional<Dependencia> findById(Integer id);
	public void create(Dependencia dependencia);
	public void update(Dependencia dependencia);
	public void delete(Integer id);
}