package com.project.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping; 
import org.springframework.web.bind.annotation.PutMapping; 
import org.springframework.web.bind.annotation.DeleteMapping; 
import org.springframework.web.bind.annotation.RequestBody; 
import org.springframework.web.bind.annotation.RequestMapping; 
import org.springframework.web.bind.annotation.RestController; 
import com.project.entities.Usuario; 
import com.project.services.IUsuarioServices; 

@RestController 
@RequestMapping("/api/usuarios")  /*la ruta base del controlador*/
public class UsuarioRestController { 
	@Autowired 
	private IUsuarioServices usuarioService; /*instancia llamada usuarioService que pertenece a la interfaz IUsuarioServices*/
	
	@GetMapping("")  /*GET localhost:8080/api/usuarios*/
	public ResponseEntity<List<Usuario>> index(){  /*Lista de Usuarios*/
		return ResponseEntity.status(HttpStatus.OK).body(usuarioService.findAll());  /*Lista de usuarios con código 200*/
	} 
	
	@GetMapping("/{id}") /*GET localhost:8080/api/usuarios/4*/
	public ResponseEntity<Optional<Usuario>> indexById(@PathVariable("id") Integer id){  /*Un usuario en especifico*/
		return ResponseEntity.status(HttpStatus.OK).body(usuarioService.findById(id));  
	} 
	
	@PostMapping("") /*POST - create */
	public ResponseEntity create(@RequestBody Usuario usuario){ 
		usuarioService.create(usuario); 
		return new ResponseEntity(HttpStatus.CREATED); /*Código 201*/
	} 
	
	@PutMapping("") /*PUT - update */
	public ResponseEntity update(@RequestBody Usuario usuario){ 
		usuarioService.update(usuario); 
		return new ResponseEntity(HttpStatus.NO_CONTENT); /*Código 204*/
	} 
	
	@DeleteMapping("/{id}") /*DELETE - update */
	public ResponseEntity delete(@PathVariable("id") Integer id){ 
		usuarioService.delete(id); 
		return new ResponseEntity(HttpStatus.NO_CONTENT); /*Código 204*/
	} 
} 

