package com.project.services;

import java.util.List;
import java.util.Optional;

import com.project.entities.Usuario;

public interface IUsuarioServices {
	
	public List<Usuario> findAll();
	public Optional<Usuario> findById(Integer id);
	public void create(Usuario usuario);
	public void update(Usuario usuario);
	public void delete(Integer id);
}
