package com.project.dao;

import org.springframework.data.repository.CrudRepository;

import com.project.entities.Dependencia;

public interface IDependenciaDao extends CrudRepository<Dependencia, Integer> {

}
