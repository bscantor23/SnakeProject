package com.project.implementacion;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.project.dao.IRolDao;
import com.project.entities.Rol;
import com.project.services.IRolServices;

@Service
public class RolServices implements IRolServices{
	
	@Autowired
	private IRolDao rolDao;
	
	@Transactional(readOnly = true)
	public List<Rol> findAll() {
		return (List<Rol>) rolDao.findAll();
	}
	
	@Transactional(readOnly = true)
	public Optional<Rol> findById(Integer id) {
		return rolDao.findById(id);
	}
	
	@Transactional(readOnly = false)
	public void create(Rol rol){
		rolDao.save(rol);
	}
	
	@Transactional(readOnly = false)
	public void update(Rol rol){
		rolDao.save(rol);
	}
	
	@Transactional(readOnly = false)
	public void delete(Integer id){
		rolDao.deleteById(id);
	}
}
