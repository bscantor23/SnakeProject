package com.schemaproductos.dao;

import org.springframework.data.repository.CrudRepository;

import com.schemaproductos.entities.Producto;

public interface IProductosDao extends CrudRepository<Producto, Long> {

}
