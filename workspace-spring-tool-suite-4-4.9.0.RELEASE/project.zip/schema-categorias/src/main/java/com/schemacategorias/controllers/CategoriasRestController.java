package com.schemacategorias.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.schemacategorias.entities.Categorias;
import com.schemacategorias.services.ICategoriasServices;

@RestController
@RequestMapping("/api/categorias")
public class CategoriasRestController {

	@Autowired
	private ICategoriasServices categoriaServices;
	
	@GetMapping("")
	public List<Categorias> listar(){
		return categoriaServices.findAll();
	}
	
	@GetMapping("/{id}")
	public Optional<Categorias> ver(@PathVariable Long id){
		return categoriaServices.findById(id);
	}
	
	@PostMapping("") /*POST - create */
	public void create(@RequestBody Categorias categoria){ 
		
		categoriaServices.create(categoria); 
	} 
}

