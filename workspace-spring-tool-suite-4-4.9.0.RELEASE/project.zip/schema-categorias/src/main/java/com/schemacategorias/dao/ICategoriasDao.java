package com.schemacategorias.dao;

import org.springframework.data.repository.CrudRepository;

import com.schemacategorias.entities.Categorias;

public interface ICategoriasDao extends CrudRepository<Categorias, Long> {

}
