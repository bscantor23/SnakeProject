package com.schemacatalogos.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.schemacatalogos.dao.ICatalogosDao;
import com.schemacatalogos.models.Catalogo;
import com.schemacatalogos.models.Producto;
import com.schemacatalogos.models.Response;
import com.schemacatalogos.models.Categoria;
import com.schemacatalogos.dao.ICatalogosDao;


@Service
public class ServicesCatalogo implements IServicesCatalogo{

	@Autowired
	private RestTemplate clienteRest;
	
	@Autowired
	private ICatalogosDao catalogoDao;
	
	@Transactional(readOnly = true)
	public List<Response> findAll(){
		
		List<Response> listResponse = new ArrayList<Response>();
		List<Catalogo> list = new ArrayList<Catalogo>();
		 
		catalogoDao.findAll().forEach(list::add);
		
		if(list.isEmpty()) {
			return listResponse;
		}
		
		for (Catalogo catalogo : list) {
			
			Long idProducto = (Long) catalogo.getId_producto();
			Producto producto = (Producto) clienteRest.getForObject("http://localhost:51478/api/productos/"+ idProducto, Producto.class);
		
			Long idCategoria = (Long) catalogo.getId_categoria();
			Categoria categoria= (Categoria) clienteRest.getForObject("http://localhost:51515/api/categorias/"+ idCategoria, Categoria.class);
		
			Response objRes = new Response(categoria,producto);
			
			System.out.println(objRes.toString());
			
			listResponse.add(objRes);
		}
		
		return listResponse;
	}
	
}	
