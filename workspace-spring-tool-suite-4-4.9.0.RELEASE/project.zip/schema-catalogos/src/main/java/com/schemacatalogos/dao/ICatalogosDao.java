package com.schemacatalogos.dao;

import org.springframework.data.repository.CrudRepository;
import com.schemacatalogos.models.Catalogo;

public interface ICatalogosDao extends CrudRepository<Catalogo, Long> {

}