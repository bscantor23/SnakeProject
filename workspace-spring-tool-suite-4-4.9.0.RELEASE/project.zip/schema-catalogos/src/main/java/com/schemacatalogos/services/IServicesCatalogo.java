package com.schemacatalogos.services;

import java.util.List;

import com.schemacatalogos.models.Catalogo;
import com.schemacatalogos.models.Categoria;
import com.schemacatalogos.models.Response;

public interface IServicesCatalogo {
	
	public List<Response> findAll();
}
