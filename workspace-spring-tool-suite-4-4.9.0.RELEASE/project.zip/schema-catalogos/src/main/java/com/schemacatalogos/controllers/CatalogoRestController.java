package com.schemacatalogos.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.schemacatalogos.models.Catalogo;
import com.schemacatalogos.models.Categoria;
import com.schemacatalogos.models.Response;
import com.schemacatalogos.services.IServicesCatalogo;
import com.schemacatalogos.services.ServicesCatalogo;

@RestController
@RequestMapping("/api/catalogos")
public class CatalogoRestController{

	@Autowired
	private IServicesCatalogo servicesCatalogo;
	
	@GetMapping("")
	public List<Response> listar(){
		return servicesCatalogo.findAll();
	}

}
