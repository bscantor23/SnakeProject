package com.schemacatalogos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchemaCatalogosApplicationTests {

	@Test
	void contextLoads() {
	}

}
